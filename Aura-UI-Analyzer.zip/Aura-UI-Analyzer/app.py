import os
import logging

from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()

logging.basicConfig(level=logging.INFO)

app = Flask(__name__)

app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024

MODEL = os.getenv(
    "GEMINI_MODEL",
    "gemini-3.8-flash"
)

ALLOWED_TYPES = {
    "image/png",
    "image/jpeg",
    "image/webp"
}


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/health")
def health():
    return jsonify({
        "success": True,
        "status": "online",
        "app": "Aura UI Analyzer AI",
        "model": MODEL
    })


@app.route("/analyze", methods=["POST"])
def analyze():

    try:

        api_key = os.getenv(
            "GEMINI_API_KEY", ""
        ).strip()

        if not api_key:
            return jsonify({
                "error": "Gemini API Key configure করা হয়নি।"
            }), 500

        if "image" not in request.files:
            return jsonify({
                "error": "Screenshot Upload করো।"
            }), 400

        image = request.files["image"]

        if not image.filename:
            return jsonify({
                "error": "Image নির্বাচন করা হয়নি।"
            }), 400

        mime_type = image.mimetype

        if mime_type not in ALLOWED_TYPES:
            return jsonify({
                "error": "PNG, JPG অথবা WEBP Image ব্যবহার করো।"
            }), 400

        image_data = image.read()

        if not image_data:
            return jsonify({
                "error": "Image ফাইল খালি।"
            }), 400

        if len(image_data) > 12 * 1024 * 1024:
            return jsonify({
                "error": "Image Size 12MB-এর বেশি হতে পারবে না।"
            }), 413

        page_type = request.form.get(
            "page_type", "Auto Detect"
        )

        language = request.form.get(
            "language", "English"
        )

        framework = request.form.get(
            "framework",
            "HTML, CSS and JavaScript"
        )

        extra = request.form.get(
            "extra", ""
        )[:2000]

        prompt = f"""
You are a professional UI reverse engineering
and frontend design analysis expert.

Your task is to analyze the attached website
screenshot and generate an extremely detailed
website recreation prompt.

USER CONFIGURATION:

Page Type: {page_type}
Coding Technology: {framework}
Output Language: {language}
Extra Instructions: {extra}

STRICT REQUIREMENTS:

1. Analyze the screenshot from top to bottom.
2. Match the visible design as closely as possible.
3. Do not invent invisible UI elements.
4. Identify the complete visual hierarchy.
5. Estimate colors and provide HEX codes.
6. Analyze typography and font weights.
7. Estimate spacing, padding and margins.
8. Describe every visible button and card.
9. Describe borders, shadows and gradients.
10. Analyze image sizes and cropping.
11. Describe icon shapes and positions.
12. Analyze navigation and footer.
13. Identify all visible text.
14. Do not guess unreadable text.
15. Describe the mobile viewport.
16. Explain responsive behavior.
17. Preserve the original screenshot proportions.
18. Separate estimated values from observed facts.
19. Do not claim to recover original source code.
20. Do not invent backend functionality.

OUTPUT STRUCTURE:

A. Screenshot Overview
B. Viewport and Dimensions
C. Complete Layout Analysis
D. Color Palette with HEX Codes
E. Typography Specification
F. Spacing and Measurements
G. Header and Navigation
H. Main Content Sections
I. Buttons and Components
J. Images and Icons
K. Mobile Responsive Instructions
L. Complete Coding Prompt
M. Visual Quality Checklist

The final coding prompt must be ready to use
in another AI coding assistant.

Output Language: {language}

Make the analysis specific to the attached image.
Avoid generic explanations.
"""

        client = genai.Client(
            api_key=api_key
        )

        response = client.models.generate_content(

            model=MODEL,

            contents=[
                types.Part.from_bytes(
                    data=image_data,
                    mime_type=mime_type
                ),
                prompt
            ],

            config=types.GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=12000
            )
        )

        result = response.text

        if not result:
            return jsonify({
                "error": "Gemini কোনো Prompt তৈরি করেনি।"
            }), 502

        return jsonify({
            "success": True,
            "model": MODEL,
            "result": result
        })

    except Exception:

        logging.exception("Gemini analysis failed")

        return jsonify({
            "error": (
                "AI Analysis Failed. API Key, Model, "
                "Quota এবং Server Logs পরীক্ষা করো।"
            )
        }), 502


@app.errorhandler(413)
def file_too_large(error):
    return jsonify({
        "error": "Maximum Image Size 12MB।"
    }), 413


@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Page not found."
    }), 404


@app.errorhandler(500)
def server_error(error):
    return jsonify({
        "error": "Internal Server Error."
    }), 500


if __name__ == "__main__":

    port = int(
        os.environ.get("PORT", 5000)
    )

    app.run(
        host="0.0.0.0",
        port=port,
        debug=False
    )